<?php
include "includes/header.php";
?>
<section class="padding-conson">
    <div class="container">
        <div class="row back-icon">
            <div class="col-12 d-flex pt-2 d-flex justify-content-between medical-pii">
                <a href="records.php" class="d-flex">
                    <i class="fas fa-chevron-left"></i>
                </a>
                <p>Attachment</p>
                <i class="fas fa-plus plus-medical"></i>
            </div>

        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="d-flex">
                        <img src="assets/images copy/gyna.jpg" alt="">
                        <p>06 Jan 2022 <span>06:30</span></p>

                    </div>

                </div>
            </div>
        </div>



    </div>

</section>
<?php
include "includes/footer.php";
?>