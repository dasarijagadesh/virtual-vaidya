<?php
include "includes/header.php";
?>
<section class="padding-conson">
    <div class="container">
        <div class="row back-icon">
            <div class="col-3 d-flex pt-2">
                <a href="records.php" class="d-flex">
                    <i class="fas fa-chevron-left"></i>

                </a>
            </div>
            <div class="col-9 d-flex pt-2">
                <p>Lab Parameters</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 Presc-r lab-para">
                <!-- <i class="fas fa-ban"></i> -->
                <p>No data to display</p>


            </div>
        </div>
    </div>

</section>
<?php
include "includes/footer.php";
?>