<?php
include "includes/header.php";
?>
<section class="padding-conson">
    <div class="container">
        <div class="row back-icon">
            <div class="col-12 d-flex pt-2">
                <a href="index.php" class="d-flex">
                    <i class="fas fa-chevron-left"></i>
                    <p class="pl-2">At-Home Lab Test</p>
                </a>

            </div>
            <!-- <div class="col-12">
                <p class="help-isssue">General Queries</p>

            </div> -->
        </div>
        <div class="row">

            <div class="col mt-2">
                <h4>Frequently Booked Tests</h4>
                <!-- <p class="color-pn"></p> -->

                <div class="d-flex text-center issues-d mt-2">

                    <div class=" column-p">
                        <div class=border-ri>
                            <img src="assets/images copy/pregency1.png" alt="">

                        </div>
                        <div>
                            <a href="consult-doctor.php">Liver Test</a>


                        </div>

                    </div>
                    <div class=" column-p">
                        <div class=border-ri>
                            <img src="assets/images copy/stress1.png" alt="">

                        </div>
                        <div>
                            <a href="consult-doctor.php">Diabets Test</a>

                        </div>


                    </div>
                    <div class=" column-p">
                        <div class=border-ri>
                            <img src="assets/images copy/pregency1.png" alt="">

                        </div>
                        <div>
                            <a href="consult-doctor.php">Thyroid Test</a>

                        </div>



                    </div>

                    <div class="column-p">
                        <div class=border-ri>
                            <img src="assets/images copy/pregency1.png" alt="">

                        </div>
                        <div>
                            <a href="consult-doctor.php">Lipid Profile</a>

                        </div>


                    </div>
                    <div class=" column-p">
                        <div class=border-ri>
                            <img src="assets/images copy/pregency1.png" alt="">

                        </div>
                        <div>
                            <a href="consult-doctor.php">Vitamin D Test</a>


                        </div>

                    </div>
                    <div class=" column-p">
                        <div class=border-ri>
                            <img src="assets/images copy/stress1.png" alt="">

                        </div>
                        <div>
                            <a href="consult-doctor.php">COVID19 RT_PRC Test</a>

                        </div>


                    </div>


                    <!-- <div class="col-3">
                            <div class=border-ri>
                                <img src="../assets/images copy/pregency1.png" alt="">

                            </div>
                            <div>
                                <a href="">Bone & Joint</a>

                            </div>



                        </div> -->

                    <div class=" column-p">
                        <div class=border-ri>
                            <img src="assets/images copy/stress1.png" alt="">

                        </div>
                        <div>
                            <a href="consult-doctor.php">PCOD Test</a>

                        </div>


                    </div>
                    <div class=" column-p">
                        <div class=border-ri>
                            <img src="assets/images copy/stress1.png" alt="">

                        </div>
                        <div>
                            <a href="consult-doctor.php">Vitamin B12 Test</a>

                        </div>


                    </div>
                    <div class=" column-p">
                        <div class=border-ri>
                            <img src="assets/images copy/stress1.png" alt="">

                        </div>
                        <div>
                            <a href="consult-doctor.php">Others</a>

                        </div>


                    </div>


                </div>
                <!-- <div class="text-center">
                    <button class="mt-4 mb-2 view-alls"> <a href=""> View All Symptoms</a>
                    </button>
                </div> -->

            </div>
        </div>
    </div>
    <div class="container ">
        <div class="row">
            <div class="col-12 mt-2 ">

                <h5>Featured Tests</h5>
                <div class="d-flex  justify-content-between button-pc">
                    <p>Upto %50% Off</p>
                    <!-- <button>view all</button> -->
                </div>
            </div>
            <div class="col-6 padding-offer-le mt-2 mb-2">
                <div class="card card-offer-tast">
                    <p>
                        72+ TESTS
                    </p>
                    <h6>
                        Vital body check <i class="fas fa-chevron-right pl-2"></i>

                    </h6>
                    <button>799 <del>2499</del></button>

                </div>

            </div>
            <div class="col-6 padding-offer-le mt-2 mb-2">
                <div class="card test-color card-offer-tast ">
                    <p>
                        72+ TESTS
                    </p>
                    <h6>
                        Vital body check <i class="fas fa-chevron-right pl-2"></i>

                    </h6>
                    <button>799 <del>2499</del></button>
                </div>

            </div>
            <div class="col-6 padding-offer-le mt-2 mb-2">
                <div class="card test-color card-offer-tast ">
                    <p>
                        72+ TESTS
                    </p>
                    <h6>
                        Vital body check <i class="fas fa-chevron-right pl-2"></i>

                    </h6>
                    <button>799 <del>2499</del></button>
                </div>

            </div>
            <div class="col-6 padding-offer-le mt-2 mb-2">
                <div class="card card-offer-tast">
                    <p>
                        72+ TESTS
                    </p>
                    <h6>
                        Vital body check <i class="fas fa-chevron-right pl-2"></i>

                    </h6>
                    <button>799 <del>2499</del></button>

                </div>

            </div>
        </div>

    </div>
    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col col-padding-tp mt-4 mb-2">
                    <h4>Condition Based Tests</h4>
                    <div class="d-flex  justify-content-between">
                        <!-- <p>common Symptoms</p> -->
                        <!-- <button>Search</button> -->
                    </div>
                    <!-- ////////slider/////////////// -->
                    <div>
                        <div id="owl-demo" class="owl-carousel owl-theme">
                            <!-- ///////////Consult-from-home-slide///////////// -->
                            <div class="item">
                                <div class=" row justify-content-s mb-2">

                                    <div class="card card-img-a pt-2 pb-2">
                                        <div>
                                            <img src="Assets/images copy/covid1.png" alt="">

                                        </div>
                                        <a href="">COVID-19</a>
                                    </div>
                                    <div class="card card-img-a pt-2 pb-2">
                                        <div>
                                            <img src="Assets/images copy/feaver.png" alt="">

                                        </div>
                                        <a href="consult-doctor.php">Diabetes</a>
                                    </div>
                                    <div class="card card-img-a pt-2 pb-2">
                                        <div>
                                            <img src="Assets/images copy/back-pain.png" alt="">

                                        </div>
                                        <a href="consult-doctor.php">Complete Blood Count</a>
                                    </div>
                                    <div class="card card-img-a pt-2 pb-2">
                                        <div>
                                            <img src="Assets/images copy/stomach.png" alt="consult-doctor.php">

                                        </div>
                                        <a href="consult-doctor.php">Thyrodi Profile</a>
                                    </div>
                                    <div class="card card-img-a pt-2 pb-2">
                                        <div>
                                            <img src="Assets/images copy/depression.png" alt="">

                                        </div>
                                        <a href="consult-doctor.php">Pregency</a>
                                    </div>
                                    <div class="card card-img-a pt-2 pb-2">
                                        <div>
                                            <img src="Assets/images copy/hair.png" alt="">

                                        </div>
                                        <a href="consult-doctor.php">Lipid Prifile</a>
                                    </div>
                                    <div class="card card-img-a pt-2 pb-2">
                                        <div>
                                            <img src="Assets/images copy/feaver.png" alt="">

                                        </div>
                                        <a href="consult-doctor.php">Kidney Function</a>
                                    </div>
                                    <div class="card card-img-a pt-2 pb-2">
                                        <div>
                                            <img src="Assets/images copy/feaver.png" alt="consult-doctor.php">

                                        </div>
                                        <a href="consult-doctor.php">Allergies</a>
                                    </div>




                                </div>
                                <!-- /////////////////////////////////// -->
                            </div>
                        </div>



                        <!-- END OF SLIDER -->


                    </div>
                </div>

            </div>
        </div>
    </section>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class=" why">
                    <div class="why-choose-card">
                        <img src="assets/images copy/blood-sample.png" alt="">
                        <p>1500+ Tests</p>

                    </div>
                    <div class="why-choose-card">
                        <img src="assets/images copy/blood-sample.png" alt="">
                        <p>At-Home Service</p>

                    </div>
                    <div class="why-choose-card">
                        <img src="assets/images copy/blood-sample.png" alt="">
                        <p>Safe & Hygienic</p>

                    </div>
                    <div class="why-choose-card">
                        <img src="assets/images copy/blood-sample.png" alt="">
                        <p>Online Reports</p>

                    </div>
                    <div class="why-choose-card">
                        <img src="assets/images copy/blood-sample.png" alt="">
                        <p>NABL Accredited Labs</p>

                    </div>
                    <div class="why-choose-card">
                        <img src="assets/images copy/blood-sample.png" alt="">
                        <p>Reports in 24-48hrs</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
include "includes/footer.php";
?>